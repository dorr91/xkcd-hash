import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class Main {
	public static void main(String [] args) throws IOException {
		System.out.println("Starting");
		Integer threadcount = new Integer(0);
		
		BufferedReader br = new BufferedReader(new FileReader("/usr/share/dict/words"));
		String[] dict = new String[99171];
		for(int i=0; i<99171; i++) {
			dict[i] = br.readLine();
		}
		
		br.close();
		
		for(String s : dict) {
			for(; threadcount >= 300;) {
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {}
			}
			String[] asList = {s};
			new Guesser(asList, dict, threadcount).start();
			threadcount ++;
		}
	}
}

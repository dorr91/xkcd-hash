import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


public class Guesser extends Thread {
	String[] dict;
	String[] prefix;
	Integer threadcount;
	
	public Guesser(String[] prefix, String[] dict, Integer threadcount) {
		this.dict = dict;
		this.prefix = prefix;
		this.threadcount = threadcount;
	}
	
	public void run() {
		String phrase = "";
		for(String s : prefix) phrase += s + " ";
		String baseParams = "hashable=" + phrase;
		String params;
		
		for(String word : dict) {
			try {
				URL url = new URL("http://almamater.xkcd.com/?edu=cmu.edu");
				params = baseParams + word;
				HttpURLConnection connection = (HttpURLConnection) url.openConnection();
				connection.setDoOutput(true);
				connection.setRequestMethod("POST");

				DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
				wr.writeBytes(params);
				wr.flush();
				
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(
								connection.getInputStream()));

				String line = reader.readLine();
				while((line = reader.readLine()) != null) {
					System.out.println(phrase + word + ": " + line.substring(303, 306));
				}

				wr.close();
				reader.close();


			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		threadcount--;
	}
}
